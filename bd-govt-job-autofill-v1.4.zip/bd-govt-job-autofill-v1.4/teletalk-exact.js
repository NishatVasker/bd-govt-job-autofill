/*
 * Specific adapter for the Teletalk application markup supplied by the user.
 * Matches only the form's public field IDs/names. Does not use page globals,
 * hidden tokens, CAPTCHA, session identifiers, declaration, or Submit.
 * Loaded in an isolated extension world when the user clicks Fill/Learn.
 */
(() => {
  'use strict';
  if (globalThis.BDG_TELETALK_EXACT) return;

  const idMap = {
    basic: { fullName:'name', fullNameBn:'name_bn', fatherName:'father',
      fatherNameBn:'father_bn', motherName:'mother', motherNameBn:'mother_bn',
      dob:'dob', nationality:'nationality', religion:'religion', gender:'gender',
      nidStatus:'nid', nidNo:'nid_no', birthStatus:'breg', birthNo:'breg_no',
      passportStatus:'passport', passportNo:'passport_no', maritalStatus:'marital_status',
      mobile:'mobile', email:'email', quota:'quota', departmental:'dep_status' },
    present: {careOf:'present_careof',road:'present_village',district:'present_district',
      upazila:'present_upazila',postOffice:'present_post',postCode:'present_postcode'},
    permanent: {sameAsPresent:'same_as_present',careOf:'permanent_careof',
      road:'permanent_village',district:'permanent_district',
      upazila:'permanent_upazila',postOffice:'permanent_post',postCode:'permanent_postcode'},
    ssc: {exam:'ssc_exam',roll:'ssc_roll',group:'ssc_group',board:'ssc_board',
      result:'ssc_result_type',gpa:'ssc_result',year:'ssc_year'},
    hsc: {exam:'hsc_exam',roll:'hsc_roll',group:'hsc_group',board:'hsc_board',
      result:'hsc_result_type',gpa:'hsc_result',year:'hsc_year'},
    graduation: {exam:'gra_exam',university:'gra_institute',year:'gra_year',
      degree:'gra_subject',result:'gra_result_type',cgpa:'gra_result',duration:'gra_duration'},
    masters: {exam:'mas_exam',university:'mas_institute',year:'mas_year',
      degree:'mas_subject',result:'mas_result_type',cgpa:'mas_result',duration:'mas_duration'},
    experience: {employed:'employment_type',designation:'designation',start:'job_start_date',
      end:'job_end_date',currentlyWorking:'currently_working',organization:'organization',
      address:'office_address',description:'job_description'}
  };
  const inForm = id => document.getElementById(id);
  const form = () => document.getElementById('applicationForm');
  const supports = () => {
    const root=form();
    return !!root && ['name','present_district','ssc_exam','hsc_exam','gra_exam','captcha']
      .every(id => root.contains(inForm(id)));
  };
  const wait = ms => new Promise(resolve => setTimeout(resolve,ms));
  const norm = str => String(str ?? '').normalize('NFKC').toLowerCase()
    .replace(/[’'`]/g,'').replace(/[^\p{L}\p{N}]/gu,'').trim();
  const isEmpty = v => v === null || v === undefined || v === '' || v === false;
  const selectable = el => el && el.isConnected && !el.disabled && !el.readOnly &&
    el.type !== 'hidden' && getComputedStyle(el).display !== 'none' &&
    getComputedStyle(el).visibility !== 'hidden' && el.getClientRects().length > 0;
  const defaultOption = opt => !opt || opt.disabled || !opt.value ||
    /^(select|choose|please select|নির্বাচন করুন)$/i.test(opt.textContent.trim());
  const selected = el => el?.selectedOptions?.[0];
  const isBlank = el => el.tagName === 'SELECT' ? defaultOption(selected(el)) :
    el.type === 'checkbox' ? !el.checked : !String(el.value).trim();

  function choose(select,wanted) {
    const options = [...select.options].filter(o => !defaultOption(o));
    const byLabel = options.filter(o => norm(o.textContent) === norm(wanted));
    if (byLabel.length === 1) return byLabel[0];
    // Codes are an exact-match fallback, not the default, because codes differ
    // between recruiting agencies (e.g., 1 means many unrelated answers).
    const byValue = options.filter(o => String(o.value).toLowerCase() === String(wanted).toLowerCase());
    return byValue.length === 1 ? byValue[0] : null;
  }
  function setInput(el,value) {
    const ctor = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement : HTMLInputElement;
    const native = Object.getOwnPropertyDescriptor(ctor.prototype,'value');
    if (native?.set) native.set.call(el,value);
    else el.value = value;
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
    el.dispatchEvent(new Event('blur',{bubbles:true}));
  }
  async function untilReady(id,wanted,maxMs=2200) {
    const start = Date.now();
    while (Date.now()-start < maxMs) {
      const el = inForm(id);
      if (selectable(el) && (el.tagName !== 'SELECT' || choose(el,wanted))) return el;
      await wait(80);
    }
    return inForm(id);
  }
  const valueInRange = (el,value) => {
    if (el.maxLength > -1 && value.length > el.maxLength) return false;
    if (el.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    if (el.type === 'date' && (el.min && value < el.min || el.max && value > el.max)) return false;
    if (el.type === 'number' && (el.min && Number(value) < Number(el.min) ||
       el.max && Number(value) > Number(el.max))) return false;
    return true;
  };
  function labelFor(field) {return `${field.section}: ${field.label}`;}
  function note(report,field,kind,reason='') {
    const label=labelFor(field);
    if (kind === 'filled') report.filled.push(label);
    else if (kind === 'already') report.unchanged++;
    else report.missing.push(`${label} (${reason || kind})`);
  }
  async function setField(el,wanted,overwrite) {
    if (!selectable(el)) return {status:'missing',why:'control is not available'};
    if (el.type === 'checkbox') {
      if (wanted !== true) return {status:'skip'};
      if (el.checked) return {status:'already'};
      el.click(); return {status:'filled'};
    }
    if (el.tagName === 'SELECT') {
      const option=choose(el,wanted);
      if (!option) return {status:'missing',why:'choice not available on this post'};
      if (el.value === option.value) return {status:'already'};
      if (!overwrite && !isBlank(el)) return {status:'missing',why:'different existing selection preserved'};
      el.value=option.value;
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
      return {status:'filled'};
    }
    const value=String(wanted);
    if (!valueInRange(el,value)) return {status:'missing',why:'outside this form’s allowed length or range'};
    if (String(el.value).trim() === value) return {status:'already'};
    if (!overwrite && !isBlank(el)) return {status:'missing',why:'different existing value preserved'};
    setInput(el,value); return {status:'filled'};
  }
  function targetFor(field) {
    if (field.confirm) return inForm('confirm_mobile');
    if (field.section === 'qualifications') {
      // These answers are job-specific: verify actual question text, not array index.
      const match = field.key === 'typingSpeed'
        ? text => /computer typing speed|typing speed.*(bangla|english)/i.test(text)
        : text => /word processing|operating fax machine/i.test(text);
      const rows = [...form().querySelectorAll('#otherExpSection .other_exp')];
      const row = rows.find(r => match(r.querySelector('label')?.textContent || ''));
      return row?.querySelector('select') || null;
    }
    if (field.section === 'experience') {
      const block=form().querySelector('.jobExpTemplate[data-index="0"]');
      return block?.querySelector('#'+idMap.experience[field.key]) || null;
    }
    return inForm(idMap[field.section]?.[field.key]);
  }
  function hasValues(group) {return Object.values(group || {}).some(v => !isEmpty(v));}
  async function enable(id) {
    const checkbox=inForm(id);
    if (checkbox && !checkbox.checked) {
      checkbox.click();
      await wait(100);
    }
  }
  async function fill(profile,overwrite) {
    const report={ok:true,filled:[],missing:[],unchanged:0};
    // Both controls begin disabled on TAX1. Use the form's own checkbox click.
    if (hasValues(profile.masters)) await enable('if_applicable_mas');
    if (hasValues(profile.experience)) await enable('if_applicable_exp');

    const parentIds = {
      'present.upazila':'present.district', 'permanent.upazila':'permanent.district',
      'ssc.group':'ssc.exam','hsc.group':'hsc.exam',
      'graduation.degree':'graduation.exam','masters.degree':'masters.exam'
    };
    const results=new Map();
    for (const field of globalThis.BDG_SCHEMA.fields) {
      if (field.section==='basic' && field.key==='post') continue; // post is user-chosen
      if (field.section==='permanent' && profile.permanent?.sameAsPresent===true &&
          field.key!=='sameAsPresent') continue;
      if (field.section==='experience' && field.key==='end' && profile.experience?.currentlyWorking===true) continue;
      const wanted=profile[field.section]?.[field.key];
      if (isEmpty(wanted)) continue;
      const path=`${field.section}.${field.key}`;
      if (parentIds[path] && results.get(parentIds[path]) === 'missing') {
        note(report,field,'missing','parent selection needs manual review');continue;
      }
      // A post may restrict the permanent district. Never use the "same"
      // checkbox if the present district cannot be selected there.
      if (path==='permanent.sameAsPresent' && wanted === true) {
        const district=inForm('permanent_district');
        const pDistrict=inForm('present_district');
        if (!district || !pDistrict?.value || ![...district.options]
          .some(o => !o.disabled && o.value===pDistrict.value)) {
          note(report,field,'missing','same-address choice is restricted on this post');
          results.set(path,'missing');continue;
        }
      }
      let el=targetFor(field);
      if (parentIds[path] && el?.tagName==='SELECT' &&
          [...el.options].filter(o=>!defaultOption(o)).length===0) {
        const [parentSection,parentKey]=parentIds[path].split('.');
        const parentField={section:parentSection,key:parentKey};
        const parent=targetFor(parentField);
        if (results.get(parentIds[path]) !== 'filled' &&
            parent?.tagName==='SELECT' && parent.value &&
            (!profile[parentSection]?.[parentKey] ||
             choose(parent,profile[parentSection][parentKey])?.value===parent.value)) {
          // The parent may have been preselected by Teletalk before the
          // dependent list was populated. Ask its normal change listener.
          parent.dispatchEvent(new Event('change',{bubbles:true}));
        }
      }
      if (el && el.tagName==='SELECT' && !choose(el,wanted) &&
          !el.disabled && !['qualifications'].includes(field.section)) {
        el=await untilReady(el.id,wanted);
      } else if (el && el.disabled && el.id) {
        el=await untilReady(el.id,wanted);
      } else if (el && ['gpa','cgpa'].includes(field.key) && !selectable(el)) {
        el=await untilReady(el.id,wanted,1100);
      }
      if (!el) {note(report,field,'missing','control not found');results.set(path,'missing');continue;}
      // Do not write a GPA into a division/class result.
      if (['gpa','cgpa'].includes(field.key)) {
        const type=targetFor({...field,key:'result'});
        if (type && !/^(gpa|cgpa)/i.test(selected(type)?.textContent.trim() || '')) {
          note(report,field,'missing','GPA/CGPA result type is not selected');
          results.set(path,'missing');continue;
        }
      }
      const res=await setField(el,wanted,overwrite);
      if (res.status !== 'skip') note(report,field,res.status,res.why);
      results.set(path,res.status);
      if (res.status === 'filled' && el.tagName==='SELECT') await wait(45);
    }
    return report;
  }
  function capture() {
    const captured=[];
    for (const field of globalThis.BDG_SCHEMA.fields) {
      if (field.kind!=='select' || field.confirm || field.section==='qualifications' ||
          field.key==='post') continue;
      const el=targetFor(field);
      if (!el || !selectable(el) || defaultOption(selected(el))) continue;
      captured.push({section:field.section,key:field.key,label:field.label,
        value:selected(el).textContent.trim()});
    }
    // Numeric GPA/CGPA lives in a separate input on TAX1. Learn its actual
    // value only when the corresponding GPA result type is selected. Never
    // read hidden application tokens or other numeric identity fields.
    for (const section of ['ssc','hsc','graduation','masters']) {
      const key = section === 'ssc' || section === 'hsc' ? 'gpa' : 'cgpa';
      const field = globalThis.BDG_SCHEMA.fields.find(f => f.section === section && f.key === key);
      const grade = targetFor(field);
      const resultType = targetFor({section,key:'result'});
      if (!selectable(grade) || !resultType || resultType.disabled ||
          !/^(gpa|cgpa)/i.test(selected(resultType)?.textContent.trim() || '')) continue;
      const value = String(grade.value || '').trim();
      if (!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(value) ||
          !valueInRange(grade,value) || !Number.isFinite(Number(value))) continue;
      captured.push({section,key,label:field.label,value});
    }
    return {ok:true,captured};
  }
  globalThis.BDG_TELETALK_EXACT={supports,fill,capture};
})();
