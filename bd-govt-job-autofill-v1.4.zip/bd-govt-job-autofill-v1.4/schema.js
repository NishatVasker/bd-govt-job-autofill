/* Editable field definitions shared by the profile screen and the Teletalk form matcher. */
(() => {
  const f = (section, key, label, aliases, kind = 'text', more = {}) =>
    ({ section, key, label, aliases, kind, ...more });
  const fields = [
    f('basic','fullName','Applicant’s Name',["applicant's name",'applicant name','name of applicant']),
    f('basic','fullNameBn','আবেদনকারীর নাম (বাংলায়)',['আবেদনকারীর নাম','name in bangla','applicant name in bangla']),
    f('basic','fatherName','Father’s Name',["father's name",'father name']),
    f('basic','fatherNameBn','পিতার নাম (বাংলায়)',['পিতার নাম','father name in bangla']),
    f('basic','motherName','Mother’s Name',["mother's name",'mother name']),
    f('basic','motherNameBn','মাতার নাম (বাংলায়)',['মাতার নাম','mother name in bangla']),
    f('basic','dob','Date of Birth',['date of birth','birth date','dob'],'date'),
    f('basic','nationality','Nationality',['nationality'],'select'),
    f('basic','religion','Religion',['religion'],'select'),
    f('basic','gender','Gender',['gender','sex'],'select'),
    f('basic','nidStatus','National ID: Yes/No',['national id','national id yes no','national identity card'],'select'),
    f('basic','nidNo','National ID Number',['national id number','nid number','national id no','nid no','national identity number']),
    f('basic','birthStatus','Birth Registration: Yes/No',['birth registration','birth certificate'],'select'),
    f('basic','birthNo','Birth Registration Number',['birth registration number','birth certificate number','birth reg number']),
    f('basic','passportStatus','Passport ID: Yes/No',['passport id','passport'],'select'),
    f('basic','passportNo','Passport Number',['passport number','passport id number','passport no']),
    f('basic','maritalStatus','Marital Status',['marital status'],'select'),
    f('basic','mobile','Mobile Number',['mobile number','mobile no','mobile','contact no','phone number']),
    f('basic','mobile','Confirm Mobile Number',['confirm mobile number','retype mobile number','confirm phone number'], 'text', {confirm: true}),
    f('basic','email','Email',['email','e mail','email address'],'text'),
    f('basic','quota','Quota',['quota'],'select'),
    f('basic','departmental','Departmental Status',['departmental status','departmental candidate'],'select'),
    f('present','careOf','Care Of',['care of','c/o']),
    f('present','road','Village / Road / House / Flat',['village road house flat','village road house flat no','village / road / house / flat','village road house']),
    f('present','district','District',['district'],'select'),
    f('present','upazila','Upazila / P.S.',['upazila p s','upazila ps','upazila','upazilla','thana','police station'],'select'),
    f('present','postOffice','Post Office',['post office','postoffice']),
    f('present','postCode','Post Code',['post code','postcode','postal code','zip code']),
    f('permanent','sameAsPresent','Same as Present Address',['same as present address','same as present','same address'],'checkbox'),
    f('permanent','careOf','Care Of',['care of','c/o']),
    f('permanent','road','Village / Road / House / Flat',['village road house flat','village road house flat no','village / road / house / flat','village road house']),
    f('permanent','district','District',['district'],'select'),
    f('permanent','upazila','Upazila / P.S.',['upazila p s','upazila ps','upazila','upazilla','thana','police station'],'select'),
    f('permanent','postOffice','Post Office',['post office','postoffice']),
    f('permanent','postCode','Post Code',['post code','postcode','postal code','zip code']),
    ...['ssc','hsc'].flatMap(section => [
      f(section,'exam','Examination',['examination','exam'],'select'),
      f(section,'roll','Roll No',['roll no','roll number','roll']),
      f(section,'group','Group / Subject',['group subject','group','subject'],'select'),
      f(section,'board','Board',['board','education board'],'select'),
      f(section,'result','Result',['result','grade','result type'],'select'),
      f(section,'gpa','GPA / Result Value',['gpa','grade point','gpa cgpa','obtained gpa','result value','gpa out of 5']),
      f(section,'year','Passing Year',['passing year','year of passing','pass year'],'select')
    ]),
    ...['graduation','masters'].flatMap(section => [
      f(section,'exam','Examination',['examination','exam'],'select'),
      f(section,'university','University / Institution',['university inst','university institution','university','institute'],'select'),
      f(section,'year','Passing Year',['passing year','year of passing','pass year'],'select'),
      f(section,'degree','Subject / Degree',['subject degree','subject','degree','subject name'],'select'),
      f(section,'result','Result',['result','grade','result type'],'select'),
      f(section,'cgpa','CGPA / Result Value',['cgpa','gpa','grade point','cgpa out of 4','result value']),
      f(section,'duration','Course Duration',['course duration','duration'],'select')
    ]),
    f('experience','employed','Employed On',['employed on','employment type'],'select'),
    f('experience','designation','Designation / Post',['designation post','designation','post held']),
    f('experience','start','Service Start Date',['from','start date','date from'],'date'),
    f('experience','end','Service End Date',['to','end date','date to'],'date'),
    f('experience','currentlyWorking','Currently Working',['currentlyworking','currently working','current working'],'checkbox'),
    f('experience','organization','Organization',['organization','organisation','employer']),
    f('experience','address','Organization Address',['address','organization address','organisation address']),
    f('experience','description','Job Description',['job description','job responsibilities'],'textarea'),
    f('qualifications','typingSpeed','Required Bangla / English typing speed',['minimum computer typing speed','typing speed','30 words in english','25 words in bangla'],'select'),
    f('qualifications','computerSkills','Computer / office skills',['word processing','email on computer','operating fax','efficiencies and experience'],'select')
  ];
  const groups = [
    { key:'basic', name:'Personal', note:'Personal information and identity. Blank fields will not be filled.' },
    { key:'present', name:'Present address', note:'Use the spelling shown in the website’s dropdowns.' },
    { key:'permanent', name:'Permanent address', note:'Use Same as Present to copy the present address where supported.' },
    { key:'ssc', name:'SSC', note:'Enter the displayed examination / board / result labels, not numeric codes.' },
    { key:'hsc', name:'HSC', note:'Enter the displayed examination / board / result labels.' },
    { key:'graduation', name:'Graduation', note:'Only fill fields applicable to your actual degree.' },
    { key:'masters', name:'Masters', note:'Leave empty when not applicable.' },
    { key:'experience', name:'Experience', note:'First job-entry block only. Dates are stored as YYYY-MM-DD.' },
    { key:'qualifications', name:'Other', note:'Job-specific questions: only select Yes if the exact requirement is true for you on that post.' }
  ];
  // Do not ship personally identifying information in distributable source.
  // An already-saved chrome.storage.local profile is preserved on upgrade.
  const defaults = {basic:{},present:{},permanent:{},ssc:{},hsc:{},
    graduation:{},masters:{},experience:{},qualifications:{}};
  globalThis.BDG_SCHEMA = Object.freeze({ fields, groups, defaults });
})();
