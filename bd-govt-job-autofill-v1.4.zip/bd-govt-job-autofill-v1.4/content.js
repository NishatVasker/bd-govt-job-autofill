/*
 * Runs only when the user clicks Fill or Learn. Isolated extension world, no network calls.
 * Intentionally NEVER clicks Next / Submit / declaration or handles CAPTCHA.
 */
(() => {
  'use strict';
  if (globalThis.__BDG_FORM_HELPER_LOADED__) return;
  globalThis.__BDG_FORM_HELPER_LOADED__ = true;

  const schema = globalThis.BDG_SCHEMA;
  if (!schema) return;
  const BLOCKED = /(captcha|verification\s*code|security\s*code|otp|one\s*time\s*password|password|পাসওয়ার্ড|যাচাই\s*কোড)/i;
  const SKIP_OPTIONS = /^(select|select one|select option|choose|choose one|please select|--+|নির্বাচন করুন|বাছাই করুন|প্রযোজ্য নয়|not selected)$/i;
  const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
  const normalized = value => String(value ?? '')
    .normalize('NFKC').toLocaleLowerCase('en')
    .replace(/[’'`]/g, '').replace(/[\u200b-\u200f]/g, '')
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim().replace(/\s+/g, ' ');
  const squashed = value => normalized(value).replace(/\s+/g, '');
  const labelText = raw => String(raw || '').replace(/\*/g,'').replace(/\s+/g,' ').trim().slice(0,200);
  const isUsable = el => {
    if (!el || !el.isConnected || el.disabled || el.readOnly) return false;
    if (el.closest('[hidden], [aria-hidden="true"], template')) return false;
    if (el.type === 'hidden' || el.type === 'password' || el.type === 'file' || el.type === 'submit') return false;
    const style = getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden' && el.getClientRects().length > 0;
  };
  const cleanText = el => {
    if (!el) return '';
    const copy = el.cloneNode(true);
    copy.querySelectorAll('input,select,textarea,button,script,style,svg,.error,.help-block,.invalid-feedback').forEach(node => node.remove());
    return labelText(copy.textContent);
  };
  function headingName(t) {
    const s = normalized(t);
    if (/^basic information$/.test(s)) return 'basic';
    if (/^(present address|বর্তমান ঠিকানা)/.test(s)) return 'present';
    if (/^(permanent address|স্থায়ী ঠিকানা|স্থায়ী ঠিকানা)/.test(s)) return 'permanent';
    if (/^(ssc|s s c)( equivalent level)?$/.test(s)) return 'ssc';
    if (/^(hsc|h s c)( equivalent level)?$/.test(s)) return 'hsc';
    if (/^(graduation|graduate)( equivalent level)?$/.test(s)) return 'graduation';
    if (/^(masters|master s?|post graduation)( equivalent level)?$/.test(s)) return 'masters';
    if (/^job experiences?( if applicable)?$/.test(s)) return 'experience';
    if (/^other qualifications?( experiences?)?$/.test(s)) return 'qualifications';
    return null;
  }
  function getMarkers() {
    const selectors = 'h1,h2,h3,h4,h5,h6,legend,th,strong,b,span,p,div,td,font';
    const nodes = document.querySelectorAll(selectors);
    const result = [];
    for (const node of nodes) {
      if (node.querySelector('input,select,textarea')) continue;
      const t = labelText(node.textContent);
      if (!t || t.length > 95) continue;
      const name = headingName(t);
      if (name) result.push({node,name});
    }
    return result;
  }
  function sectionOf(el, markers) {
    let section = 'basic';
    for (const m of markers) {
      if (m.node === el || m.node.contains(el)) continue;
      if (m.node.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING) section = m.name;
      else break;
    }
    return section;
  }
  function getLabels(el) {
    const labels = [];
    const add = text => {text = labelText(text); if (text && !labels.includes(text)) labels.push(text);};
    if (el.labels) for (const label of el.labels) add(cleanText(label));
    for (const attr of ['aria-label','placeholder','title']) add(el.getAttribute(attr));
    if (el.id) {
      for (const label of document.querySelectorAll('label[for]')) if (label.htmlFor === el.id) add(cleanText(label));
    }
    const td = el.closest('td,th');
    if (td) {
      add(cleanText(td));
      for (let sibling = td.previousElementSibling, n = 0; sibling && n < 2; sibling = sibling.previousElementSibling,n++) {
        if (sibling.matches('td,th')) add(cleanText(sibling));
      }
    }
    const group = el.closest('.form-group,.form-row,.input-group,.form-field,.field,fieldset');
    if (group) {
      const text = cleanText(group);
      if (text.length < 145) add(text);
      for (const label of group.querySelectorAll('label')) add(cleanText(label));
    }
    // A previous *table row* is another field, never evidence for this one.
    let node = el;
    for (let i=0; !td && i<3 && node; i++,node=node.parentElement) {
      if (node.previousElementSibling) {
        const text = cleanText(node.previousElementSibling);
        if (text.length < 120) add(text);
      }
      const own = cleanText(node);
      if (own.length < 90) add(own);
    }
    return labels;
  }
  function candidateKinds(field, el) {
    const tag = el.tagName.toLowerCase();
    const type = (el.type || '').toLowerCase();
    if (field.kind === 'checkbox') return type === 'checkbox';
    if (field.kind === 'select') return tag === 'select' || type === 'radio';
    if (field.kind === 'textarea') return tag === 'textarea' || (tag === 'input' && /^(text)$/.test(type));
    if (field.kind === 'date') return tag === 'input' && /^(date|text)$/.test(type);
    return tag === 'textarea' || (tag === 'input' && /^(text|number|tel|email)$/.test(type));
  }
  function aliasScore(labels, field) {
    let score = 0;
    for (const raw of labels) {
      if (BLOCKED.test(raw)) continue;
      const label = normalized(raw);
      for (const a of field.aliases) {
        const alias = normalized(a);
        if (!alias) continue;
        if (label === alias) score = Math.max(score,120);
        else if (label.startsWith(alias + ' ') || label.endsWith(' ' + alias)) score = Math.max(score,100);
        else if (field.section === 'qualifications' && alias.length >= 13 && label.includes(alias)) score = Math.max(score,88);
      }
    }
    return score;
  }
  function idScore(field, el) {
    const raw = squashed((el.getAttribute('name') || '') + ' ' + (el.id || ''));
    if (!raw) return 0;
    const key = squashed(field.key);
    const special = {
      fullName:['appname','applicantname','candidatename'],
      fullNameBn:['appnamebn','appnamebangla','banglaname'],
      fatherName:['fathername','fname'],fatherNameBn:['fathernamebn','fnamebn'],
      motherName:['mothername','mname'],motherNameBn:['mothernamebn','mnamebn'],
      dob:['dob','dateofbirth'],nidNo:['nidno','nidnumber','nationalidnumber'],
      mobile:['mobile','mobileno','mobilenumber','contactnumber'],
      email:['email','emailaddress'],postCode:['postcode','zipcode','postalcode'],
      district:['district','dist'],upazila:['upazila','upazilla','thana','ps'],
      roll:['rollno','rollnumber'],year:['passingyear','passyear']
    };
    const hints = [...(special[field.key] || []),key];
    for (const hint of hints) if (raw === hint) return 76;
    for (const hint of hints) if (hint.length >= 5 && raw.includes(hint)) return 50;
    return 0;
  }
  function serviceDateScore(field, el) {
    if (field.section !== 'experience' || !['start','end'].includes(field.key)) return null;
    const group = el.closest('tr,.form-group,.form-row,.row,fieldset');
    if (!group) return null;
    const text = normalized(cleanText(group));
    const dates = [...group.querySelectorAll('input')].filter(x => ['date','text'].includes(x.type) && isUsable(x));
    if (dates.length < 2 || (!text.includes('length of service') && !text.includes('service period'))) return null;
    return dates.indexOf(el) === (field.key === 'start' ? 0 : 1) ? 145 : -1;
  }
  function findMatches(field, elements, markers) {
    const scored = [];
    for (const el of elements) {
      if (!isUsable(el) || !candidateKinds(field,el)) continue;
      const section = sectionOf(el,markers);
      if (section !== field.section) continue;
      const labels = getLabels(el);
      let score = aliasScore(labels,field);
      const dateIndex = serviceDateScore(field,el);
      if (dateIndex === -1) continue;
      if (dateIndex !== null) score = Math.max(score,dateIndex);
      // Never guess the source of an unlabeled repeating field based only on its ID.
      score = Math.max(score,idScore(field,el));
      if (field.confirm && !labels.some(t => /confirm|retype|পুনরায়/i.test(t))) continue;
      if (!field.confirm && field.key === 'mobile' && labels.some(t => /^confirm|^retype/i.test(t))) continue;
      if (field.key === 'nidStatus' && /number|no$/i.test((el.name||'') + ' ' + (el.id||''))) continue;
      if (field.key === 'nidNo' && labels.some(t => normalized(t) === 'national id')) continue;
      if (score >= 50) scored.push({el,score,labels});
    }
    scored.sort((a,b) => b.score - a.score);
    return scored;
  }
  function setNative(el, value) {
    const descriptor = Object.getOwnPropertyDescriptor(
      el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,'value');
    if (descriptor?.set) descriptor.set.call(el,value);
    else el.value=value;
    el.dispatchEvent(new Event('input',{bubbles:true}));
    el.dispatchEvent(new Event('change',{bubbles:true}));
    el.dispatchEvent(new Event('blur',{bubbles:true}));
  }
  const nothingSelected = el => {
    if (!el) return true;
    if (el.tagName.toLowerCase() !== 'select') return !el.checked;
    const opt = el.selectedOptions?.[0];
    return !opt || !el.value || SKIP_OPTIONS.test(labelText(opt.textContent)) ||
      (el.selectedIndex === 0 && (String(el.value) === '0' || /^select/i.test(labelText(opt.textContent))));
  };
  function optionFor(el,wanted) {
    const target = normalized(wanted);
    if (!target) return null;
    const opts = [...el.options].filter(opt => !opt.disabled && !SKIP_OPTIONS.test(labelText(opt.textContent)));
    let option = opts.find(opt => normalized(opt.textContent) === target);
    if (!option) option = opts.find(opt => normalized(opt.value) === target);
    // Teletalk varies punctuation: SSC and S.S.C should match. Avoid loose
    // prefixes: "Science" must never accidentally select "Science Vocational".
    if (!option) option = opts.find(opt => squashed(opt.textContent) === squashed(wanted));
    return option || null;
  }
  function dateFormat(iso, field, el) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(iso))) return iso;
    if (el.type === 'date') return iso;
    const [yyyy,mm,dd] = iso.split('-');
    if (field.section === 'experience') return `${mm}/${dd}/${yyyy}`;
    return `${dd}/${mm}/${yyyy}`;
  }
  function radioText(el) {
    const label = el.labels && el.labels[0] ? cleanText(el.labels[0]) : '';
    const sibling = el.nextElementSibling ? cleanText(el.nextElementSibling) : '';
    return [label,sibling,el.value].filter(Boolean);
  }
  function applyOne(field, item, rawValue, overwrite) {
    const {el} = item;
    if (field.kind === 'checkbox') {
      if (rawValue !== true) return 'skip';
      if (el.checked) return 'already';
      el.click();
      return 'filled';
    }
    if (el.type === 'radio') {
      const radio = findMatches(field,[...document.querySelectorAll('input[type="radio"]')],getMarkers());
      const wanted = normalized(rawValue);
      const target = radio.find(({el:r}) => radioText(r).some(x => normalized(x) === wanted));
      if (!target) return 'option';
      if (target.el.checked) return 'already';
      if (!overwrite && radio.some(({el:r}) => r.checked)) return 'already';
      target.el.click();
      return 'filled';
    }
    if (el.tagName.toLowerCase() === 'select') {
      const selected = optionFor(el,rawValue);
      if (!selected) return 'option';
      if (el.value === selected.value) return 'already';
      if (!overwrite && !nothingSelected(el)) return 'already';
      el.value = selected.value;
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
      return 'filled';
    }
    let wanted = field.kind === 'date' ? dateFormat(String(rawValue),field,el) : String(rawValue);
    if (String(el.value).trim() === wanted) return 'already';
    if (!overwrite && String(el.value).trim()) return 'already';
    setNative(el,wanted);
    return 'filled';
  }
  // Read only deliberately selected dropdowns. Do not capture raw IDs, phone,
  // date, CAPTCHA or post-specific eligibility answers.
  function captureDropdowns() {
    const elements = [...document.querySelectorAll('select')];
    const markers = getMarkers();
    const used = new Set();
    const captured = [];
    for (const field of schema.fields) {
      if (field.kind !== 'select' || field.confirm ||
          field.key === 'post' || field.section === 'qualifications') continue;
      const candidate = findMatches(field,elements,markers)
        .find(item => !used.has(item.el) && !nothingSelected(item.el));
      if (!candidate) continue;
      const option = candidate.el.selectedOptions?.[0];
      if (!option || option.disabled) continue;
      const value = labelText(option.textContent);
      if (!value || SKIP_OPTIONS.test(value)) continue;
      used.add(candidate.el);
      captured.push({section:field.section,key:field.key,label:field.label,value});
    }
    // Generic Teletalk forms: cautiously learn a *uniquely matched* visible
    // GPA/CGPA input, and only if the linked result dropdown is GPA/CGPA.
    // This does not attempt to learn other text/number fields.
    for (const section of ['ssc','hsc','graduation','masters']) {
      const key = section === 'ssc' || section === 'hsc' ? 'gpa' : 'cgpa';
      const gradeField = schema.fields.find(f => f.section === section && f.key === key);
      const resultField = schema.fields.find(f => f.section === section && f.key === 'result');
      const matches = findMatches(gradeField,[...document.querySelectorAll('input')],markers);
      const resultChoices = findMatches(resultField,elements,markers);
      if (matches.length !== 1 || resultChoices.length !== 1) continue;
      const grade = matches[0].el;
      const type = resultChoices[0].el;
      if (type.tagName !== 'SELECT' || !/^(gpa|cgpa)/i.test(type.selectedOptions?.[0]?.textContent.trim() || '')) continue;
      const value = String(grade.value || '').trim();
      if (!/^(?:\d+(?:\.\d+)?|\.\d+)$/.test(value) || !Number.isFinite(Number(value)) ||
          (grade.min !== '' && Number(value) < Number(grade.min)) ||
          (grade.max !== '' && Number(value) > Number(grade.max))) continue;
      captured.push({section,key,label:gradeField.label,value});
    }
    // v1.4: capture visible identity/contact/text values from the current completed form.
    // The user controls when this runs; values stay in chrome.storage.local.
    // Avoid security fields and empty values.
    const textElements = [...document.querySelectorAll('input,textarea')];
    const textUsed = new Set();
    for (const field of schema.fields) {
      if (field.kind === 'select' || field.kind === 'checkbox' || field.confirm) continue;
      if (!['basic','present','permanent','ssc','hsc','graduation','masters','experience'].includes(field.section)) continue;
      const candidates = findMatches(field,textElements,markers)
        .filter(item => !textUsed.has(item.el));
      if (candidates.length !== 1) continue;
      const value = String(candidates[0].el.value || '').trim();
      if (!value || BLOCKED.test(value)) continue;
      textUsed.add(candidates[0].el);
      captured.push({section:field.section,key:field.key,label:field.label,value});
    }
    return {ok:true,captured};
  }
  async function fillForm(profile,overwrite) {
    const report = {ok:true,filled:[],missing:[],unchanged:0};
    const attempted = new Map();
    const formElements = () => [...document.querySelectorAll('input,select,textarea')];
    // More than one pass is required for dependent lists (district ->
    // upazila, exam -> group / result). Time is bounded; never guess an option.
    const retryDelays = [200,400,750,1200,2000];
    for (let pass=0;pass<=retryDelays.length;pass++) {
      const elements = formElements();
      const markers = getMarkers();
      for (const field of schema.fields) {
        if (field.section === 'permanent' && profile.permanent?.sameAsPresent === true && field.key !== 'sameAsPresent') continue;
        const raw = profile[field.section]?.[field.key];
        if (raw === '' || raw === undefined || raw === null || raw === false) continue;
        if (field.section === 'experience' && field.key === 'end' && profile.experience?.currentlyWorking === true) continue;
        const name = `${field.section}: ${field.label}`;
        if (attempted.get(name) === 'filled' || attempted.get(name) === 'already') continue;
        const choices = findMatches(field,elements,markers);
        if (!choices.length) {attempted.set(name,'notfound');continue;}
        const result = applyOne(field,choices[0],raw,overwrite);
        attempted.set(name,result);
      }
      if (pass < retryDelays.length && [...attempted.values()].some(v => v === 'option' || v === 'notfound')) {
        await pause(retryDelays[pass]);
      }
    }
    for (const [label,result] of attempted) {
      if (result === 'filled') report.filled.push(label);
      else if (result === 'already') report.unchanged += 1;
      else if (result !== 'skip') report.missing.push(`${label} (${result === 'option' ? 'option not available' : 'not found'})`);
    }
    return report;
  }
  chrome.runtime.onMessage.addListener((message,sender,sendResponse) => {
    if (message?.action !== 'BDG_FILL' && message?.action !== 'BDG_CAPTURE_DROPDOWNS') return false;
    const host = location.hostname.toLowerCase();
    if (!(host === 'teletalk.com.bd' || host.endsWith('.teletalk.com.bd'))) {
      sendResponse({ok:false,error:'Unsupported website. Only Teletalk recruitment forms are permitted.'});
      return false;
    }
    const exact = globalThis.BDG_TELETALK_EXACT;
    const operation = exact?.supports()
      ? (message.action === 'BDG_CAPTURE_DROPDOWNS'
        ? Promise.resolve(exact.capture())
        : exact.fill(message.profile || {},message.overwrite === true))
      : (message.action === 'BDG_CAPTURE_DROPDOWNS'
        ? Promise.resolve(captureDropdowns())
        : fillForm(message.profile || {},message.overwrite === true));
    operation
      .then(sendResponse)
      .catch(error => sendResponse({ok:false,error:String(error.message || error)}));
    return true;
  });
})();
