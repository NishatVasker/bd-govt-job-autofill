BD Govt Job Autofill Helper v1.4

Updates:
- Captures identity/contact text fields during Learn mode (NID, birth registration, passport, mobile, email and other visible fields).
- Keeps existing dropdown and CGPA handling.
- Improved support for dependent Teletalk fields through repeated fill passes.
- Does not fill CAPTCHA or submit applications automatically.

Install: extract ZIP -> chrome://extensions -> Developer mode -> Load unpacked.
