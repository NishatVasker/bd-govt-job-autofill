(() => {
  'use strict';
  const {fields, groups, defaults} = BDG_SCHEMA;
  const $ = id => document.getElementById(id);
  const deepcopy = value => JSON.parse(JSON.stringify(value));
  let profile = deepcopy(defaults);
  let active = 'basic';
  let initialized = false;

  function status(message, type = '') {
    const el = $('status');
    el.className = 'status' + (type ? ' ' + type : '');
    el.textContent = message;
  }
  function getValue(field) {
    const value = profile[field.section]?.[field.key];
    return value === undefined || value === null ? '' : value;
  }
  function makeInput(field) {
    const wrapper = document.createElement('div');
    wrapper.className = 'field' + (field.kind === 'textarea' || field.key === 'road' ? ' wide' : '') + (field.kind === 'checkbox' ? ' check' : '');
    const id = `f-${field.section}-${field.key}${field.confirm ? '-confirm' : ''}`;
    const label = document.createElement('label');
    label.htmlFor = id;
    label.textContent = field.label;
    const el = document.createElement(field.kind === 'textarea' ? 'textarea' : 'input');
    el.id = id;
    el.dataset.section = field.section;
    el.dataset.key = field.key;
    el.autocomplete = 'off';
    if (field.kind !== 'textarea') el.type = field.kind === 'date' ? 'date' : field.kind === 'checkbox' ? 'checkbox' : 'text';
    if (field.kind === 'checkbox') {
      wrapper.append(el,label);
      el.checked = getValue(field) === true;
    } else {
      wrapper.append(label,el);
      el.value = String(getValue(field));
    }
    if (field.confirm) {
      const small = document.createElement('small');
      small.textContent = 'Automatically repeats Mobile Number; no second value needed.';
      wrapper.append(small);
      el.readOnly = true;
    } else {
      const store = () => {
        if (!profile[field.section]) profile[field.section] = {};
        profile[field.section][field.key] = field.kind === 'checkbox' ? el.checked : el.value.trim();
        if (field.section === 'basic' && field.key === 'mobile') {
          const confirmInput = $('f-basic-mobile-confirm');
          if (confirmInput) confirmInput.value = el.value;
        }
        setDirty();
      };
      el.addEventListener(field.kind === 'checkbox' ? 'change' : 'input', store);
      if (field.kind === 'date') el.addEventListener('change', store);
    }
    return wrapper;
  }
  function renderTabs() {
    const tabs = $('tabs');
    tabs.textContent = '';
    for (const group of groups) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = group.name;
      btn.className = group.key === active ? 'active' : '';
      btn.setAttribute('aria-pressed', String(group.key === active));
      btn.addEventListener('click', () => {active = group.key; renderTabs(); renderFields();});
      tabs.append(btn);
    }
  }
  function renderFields() {
    $('sectionIntro').textContent = groups.find(g => g.key === active).note;
    const root = $('fields');
    root.textContent = '';
    for (const field of fields) {
      if (field.section === active) root.append(makeInput(field));
    }
  }
  let dirty = false;
  function setDirty() {
    dirty = true;
    $('save').textContent = 'Save changes';
  }
  async function save() {
    await chrome.storage.local.set({bdgProfile:profile});
    dirty = false;
    $('save').textContent = 'Saved ✓';
    status('Profile saved on this device. Open a Teletalk application to fill it.', 'good');
  }
  async function getApplicationTab() {
    const tabs = await chrome.tabs.query({active:true,currentWindow:true});
    const tab = tabs[0];
    if (!tab?.id || !/^https?:\/\//.test(tab.url || '')) {
      throw new Error('Open the actual application form in a normal browser tab first.');
    }
    const host = new URL(tab.url).hostname.toLowerCase();
    if (!(host === 'teletalk.com.bd' || host.endsWith('.teletalk.com.bd'))) {
      throw new Error('For your privacy, this version works only on Teletalk recruitment sites (*.teletalk.com.bd).');
    }
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['schema.js','teletalk-exact.js','content.js']});
    return tab;
  }
  async function learn() {
    $('learn').disabled = true;
    try {
      const tab = await getApplicationTab();
      const result = await chrome.tabs.sendMessage(tab.id,{action:'BDG_CAPTURE_DROPDOWNS'});
      if (!result?.ok) throw new Error(result?.error || 'Could not inspect the dropdowns.');
      const captured = result.captured || [];
      if (!captured.length) {
        status('No dropdowns or GPA/CGPA values were recognized. First select your details in the Teletalk form, then try again.', 'bad');
        return;
      }
      const changed = captured.filter(item => String(profile[item.section]?.[item.key] || '') !== item.value);
      const replaced = changed.filter(item => String(profile[item.section]?.[item.key] || '').trim());
      if (!changed.length) {
        status(`${captured.length} selected choice(s) / GPA values already match your saved profile.`, 'good');
        return;
      }
      const examples = changed.slice(0,7).map(item => `${item.section} · ${item.label}: ${item.value}`).join('\n');
      const question = `Save ${changed.length} dropdown / GPA / CGPA value(s) from this form?\n`+
        (replaced.length ? `This will replace ${replaced.length} previously saved choice(s).\n` : '')+
        `\n${examples}${changed.length > 7 ? '\n…' : ''}\n\nReview that these are YOUR correct details.`;
      if (!confirm(question)) {
        status('No dropdown choices were saved.');
        return;
      }
      for (const item of changed) {
        if (!profile[item.section]) profile[item.section] = {};
        profile[item.section][item.key] = item.value;
      }
      await chrome.storage.local.set({bdgProfile:profile});
      dirty = false;
      $('save').textContent = 'Saved ✓';
      renderFields();
      status(`Saved ${changed.length} choice(s) and/or GPA/CGPA value(s). Next time, use “Fill current form”. Options unavailable on another site will be left for manual review.`, 'good');
    } catch (err) {
      status(`Could not learn choices: ${err.message || String(err)}`, 'bad');
    } finally {
      $('learn').disabled = false;
    }
  }
  async function fill() {
    $('fill').disabled = true;
    try {
      // Saving before filling is intentional: profile edits remain on this device.
      await chrome.storage.local.set({bdgProfile:profile});
      dirty = false;
      $('save').textContent = 'Saved ✓';
      const tab = await getApplicationTab();
      const result = await chrome.tabs.sendMessage(tab.id,{action:'BDG_FILL',profile,overwrite:$('overwrite').checked});
      if (!result?.ok) throw new Error(result?.error || 'Could not access the application fields.');
      const filled = result.filled || [];
      const missing = result.missing || [];
      const notice = `Filled ${filled.length} field(s). ${result.unchanged || 0} already complete. ${missing.length} saved field(s) not matched / dropdown value unavailable.\n` +
        (missing.length ? `Check manually: ${missing.slice(0,8).join('; ')}${missing.length > 8 ? '…' : ''}\n` : '') +
        'Review every answer. Complete the verification code and submit yourself.';
      status(notice, missing.length ? 'bad' : 'good');
    } catch (err) {
      status(`Could not fill: ${err.message || String(err)}`, 'bad');
    } finally {
      $('fill').disabled = false;
    }
  }
  async function reset() {
    if (!confirm('Reset your saved profile to an empty profile? This clears values you entered.')) return;
    profile = deepcopy(defaults);
    await chrome.storage.local.set({bdgProfile:profile});
    renderFields();
    status('Profile reset to an empty profile.', 'good');
  }
  async function init() {
    try {
      const result = await chrome.storage.local.get('bdgProfile');
      if (result.bdgProfile && typeof result.bdgProfile === 'object') profile = result.bdgProfile;
      renderTabs();
      renderFields();
      $('save').addEventListener('click', save);
      $('fill').addEventListener('click', fill);
      $('learn').addEventListener('click', learn);
      $('reset').addEventListener('click', reset);
      initialized = true;
    } catch (err) {status(`Cannot read local profile: ${err.message}`, 'bad');}
  }
  init();
})();
