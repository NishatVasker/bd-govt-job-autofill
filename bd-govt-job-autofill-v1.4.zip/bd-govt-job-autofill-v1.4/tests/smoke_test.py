"""Run: python tests/smoke_test.py (requires Playwright and local Chromium)."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
fixture = (ROOT / 'tests/teletalk-fixture.html').read_text(encoding='utf-8')
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
    page = browser.new_page()
    page.set_content(fixture)
    page.evaluate("window.chrome = {runtime:{onMessage:{addListener(fn){window.__handler=fn}}}}")
    page.add_script_tag(path=str(ROOT/'schema.js'))
    # The test uses file://; bypass only the hostname guard in the TEST COPY, never in the shipped extension.
    contents = (ROOT/'content.js').read_text(encoding='utf-8')
    contents = contents.replace("if (!(host === 'teletalk.com.bd' || host.endsWith('.teletalk.com.bd'))) {", 'if (false) {')
    page.add_script_tag(content=contents)
    profile = {
       'basic':{'fullName':'Example Applicant','fatherName':'EXAMPLE FATHER','motherName':'EXAMPLE MOTHER',
                'fullNameBn':'উদাহরণ','dob':'2000-06-04','nationality':'Bangladeshi','religion':'Islam',
                'gender':'Male','nidStatus':'Yes','nidNo':'777444111000','mobile':'01711111111','email':'example@example.invalid'},
       'present':{'careOf':'Father','road':'Main Road','district':'Dhaka','upazila':'Savar','postOffice':'Savar','postCode':'1340'},
       'permanent':{'sameAsPresent':True},
       'ssc':{'exam':'SSC','roll':'12345','group':'Science','board':'Dhaka','result':'GPA(Out of 5)','gpa':'5.00','year':'2018'},
       'hsc':{'exam':'HSC','roll':'67890','group':'Science','board':'Dhaka','result':'GPA(Out of 5)','year':'2020'},
       'graduation':{'exam':'Bachelor','university':'Dhaka University','year':'2024','degree':'Computer Science','result':'CGPA(Out of 4)','cgpa':'3.9','duration':'4 Years'},
       'masters':{},
       'experience':{'employed':'Regular','designation':'Officer','start':'2024-09-01','end':'2025-10-01','organization':'Test Ltd','address':'Dhaka','description':'Job details'},
       'qualifications':{'typingSpeed':'Yes','computerSkills':'Yes'}
    }
    result = page.evaluate('''profile=>new Promise((resolve,reject)=>{
        window.__handler({action:'BDG_FILL',profile,overwrite:false},null,r=>resolve(r));
    })''',profile)
    values = page.evaluate('''() => ({
      fullName:document.querySelector('#app_name').value,
      bangla:document.querySelector('#app_name_bn').value,
      father:document.querySelector('#father_name').value,
      dob:document.querySelector('#date_of_birth').value,
      nid:document.querySelector('#nid_no').value,
      mobile:document.querySelector('#mobile').value,
      confirm:document.querySelector('#mobile_confirm').value,
      district:document.querySelector('#present-district').value,
      upazila:document.querySelector('#present-upazila').value,
      same:document.querySelector('#same').checked,
      ssc:document.querySelector('#ssc-roll').value,
      hsc:document.querySelector('#hsc-roll').value,
      graduation:document.querySelector('#graduation-university').value,
      captcha:document.querySelector('#captcha').value,
      declaration:document.querySelector('#declaration').checked,
      start:document.querySelector('#experience-from').value,
      end:document.querySelector('#experience-to').value,
      description:document.querySelector('#experience-description').value,
      typing:document.querySelector('#qual1').value,
      skills:document.querySelector('#qual2').value
    })''')
    print('first run:',json.dumps(result,ensure_ascii=False,indent=2))
    print('values:',json.dumps(values,ensure_ascii=False,indent=2))
    expected = dict(fullName='Example Applicant',bangla='উদাহরণ',father='EXAMPLE FATHER',dob='04/06/2000',
                    nid='777444111000',mobile='01711111111',confirm='01711111111',district='13',upazila='savar',
                    same=True,ssc='12345',hsc='67890',graduation='Dhaka University',captcha='',declaration=False,
                    start='09/01/2024',end='10/01/2025',description='Job details',typing='Yes',skills='Yes')
    errors = {k:(values.get(k),v) for k,v in expected.items() if values.get(k)!=v}
    print('FAILED FIELDS:',errors)
    assert not errors, errors
    assert len(result['filled']) >= 32, result
    second = page.evaluate('''profile=>new Promise(resolve=>window.__handler({action:'BDG_FILL',profile,overwrite:false},null,resolve))''',profile)
    print('second run filled:',len(second['filled']),'unchanged:',second['unchanged'])
    assert not second['filled'],second
    assert second['unchanged'] >= 32,second
    print('PASS: populated representative fields, dependent dropdown, and avoided CAPTCHA, declaration, and submission.')
    browser.close()
