"""Regression: selected-option capture, punctuation matching and slow dependent dropdown."""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
fixture = (ROOT / 'tests/teletalk-fixture.html').read_text(encoding='utf-8')
contents = (ROOT / 'content.js').read_text(encoding='utf-8').replace(
    "if (!(host === 'teletalk.com.bd' || host.endsWith('.teletalk.com.bd'))) {", 'if (false) {'
)

def inject(page, html):
    page.set_content(html)
    page.evaluate("window.chrome = {runtime:{onMessage:{addListener(fn){window.__handler=fn}}}}")
    page.add_script_tag(path=str(ROOT / 'schema.js'))
    page.add_script_tag(content=contents)

def invoke(page, action, profile=None):
    return page.evaluate('''arg => new Promise(resolve =>
        window.__handler({action: arg.action,profile:arg.profile || {},overwrite:false},null,resolve)
    )''', {'action': action, 'profile': profile})

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
    page = browser.new_page()
    inject(page, fixture)
    page.select_option('#present-district', label='Dhaka')
    page.wait_for_timeout(250)
    page.select_option('#present-upazila', label='Savar')
    page.select_option('#ssc-exam', label='SSC')
    page.select_option('#ssc-board', label='Dhaka')
    page.select_option('#ssc-result', label='GPA(Out of 5)')
    page.select_option('#ssc-year', label='2018')
    page.select_option('#qual1', label='Yes')
    page.fill('#ssc-gpa','4.62')
    selected = invoke(page, 'BDG_CAPTURE_DROPDOWNS')['captured']
    indexed = {(item['section'],item['key']):item['value'] for item in selected}
    assert indexed[('present','district')] == 'Dhaka', indexed
    assert indexed[('present','upazila')] == 'Savar', indexed
    assert indexed[('ssc','exam')] == 'SSC', indexed
    assert indexed[('ssc','result')] == 'GPA(Out of 5)', indexed
    assert indexed[('ssc','year')] == '2018', indexed
    assert indexed[('ssc','gpa')] == '4.62', indexed
    assert not any(x['section'] == 'qualifications' or x['key'] == 'post' for x in selected), indexed
    print('PASS: learns dropdown labels plus visible GPA, skipping post-specific responses.')

    page.evaluate('''() => {
      const el = document.querySelector('#ssc-exam');
      el.options[1].textContent = 'S.S.C';
      el.selectedIndex = 0;
    }''')
    result = invoke(page, 'BDG_FILL', {'ssc':{'exam':'SSC'}})
    assert 'ssc: Examination' in result['filled'], result
    assert page.locator('#ssc-exam').input_value() == 'S.S.C'
    print('PASS: SSC profile text matches the S.S.C dropdown spelling.')

    page.evaluate('''() => {
      const el = document.querySelector('#ssc-exam');
      el.options[1].textContent = 'S.S.C Vocational';
      el.selectedIndex = 0;
    }''')
    result = invoke(page, 'BDG_FILL', {'ssc':{'exam':'SSC'}})
    assert any('Examination (option not available)' in m for m in result['missing']),result
    assert page.locator('#ssc-exam').input_value() == ''
    print('PASS: dissimilar dropdown values are not guessed.')

    page = browser.new_page()
    inject(page, fixture.replace('},160));</script>', '},1400));</script>'))
    result = invoke(page, 'BDG_FILL', {'present':{'district':'Dhaka','upazila':'Savar'}})
    assert page.locator('#present-upazila').input_value() == 'savar', result
    print('PASS: district -> upazila dependent dropdown loads after 1.4 seconds.')
    browser.close()
