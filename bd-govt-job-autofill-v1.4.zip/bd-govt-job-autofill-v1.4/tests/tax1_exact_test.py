"""Offline regression against a sanitized copy of the user's exact TAX1 DOM.
No live requests, real session secrets, or user's personal data are involved.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
FIXTURE=(ROOT/'tests/tax1-markup-fixture.html').read_text(encoding='utf8')
ORIGIN=ROOT.joinpath('content.js').read_text(encoding='utf8').replace(
    "if (!(host === 'teletalk.com.bd' || host.endsWith('.teletalk.com.bd'))) {", 'if (false) {'
)
SIMULATION = '''() => {
  const $ = id => document.getElementById(id);
  const add=(id,cb) => $(id)?.addEventListener('change',cb);
  add('present_district',() => setTimeout(() => {
    $('present_upazila').innerHTML = `<option value="" disabled selected>Select</option><option value="323">Khilgaon</option><option value="341">Savar</option>`;
  }, 160));
  add('permanent_district',() => setTimeout(() => {
    $('permanent_upazila').innerHTML = `<option value="" disabled selected>Select</option><option value="323">Khilgaon</option>`;
  }, 160));
  for (const p of ['ssc','hsc']) {
    add(p+'_exam',() => setTimeout(() => {
      $(p+'_group').innerHTML = `<option value="" disabled selected>Select</option><option value="1">Science</option><option value="2">Humanities</option>`;
    }, 200));
  }
  add('gra_exam',() => setTimeout(() => {
    $('gra_subject').innerHTML = `<option value="" disabled selected>Select</option><option value="394">Computer Science & Engineering</option><option value="303">Civil Engineering</option>`;
  }, 220));
  for (const p of ['ssc','hsc','gra','mas']) {
    add(p+'_result_type',() => {
      const g=$(p+'_result');
      g.style.setProperty('display',/GPA/i.test($(p+'_result_type').selectedOptions[0]?.textContent||'') ? 'inline-block' : 'none','important');
    });
  }
  // The actual site uses onChangeId() to reveal the associated ID field.
  for (const [choice,section] of [['nid','nationalIdElm'],['breg','bregElm'],
                                   ['passport','passId'],['marital_status','maritalElm'],
                                   ['quota','quotaDetailsElm']]) {
    add(choice,() => $(section)?.classList.remove('hide'));
  }
  $('if_applicable_mas').addEventListener('click',()=> {
    for (const el of $('masSection').querySelectorAll('select,input:not(#if_applicable_mas)')) el.disabled=!$('if_applicable_mas').checked;
  });
  $('if_applicable_exp').addEventListener('click',()=> {
    for (const el of $('expSection').querySelectorAll('select,input:not(#if_applicable_exp),textarea')) el.disabled=!$('if_applicable_exp').checked;
  });
  $('same_as_present').addEventListener('click',()=> {
    if (!$('same_as_present').checked) return;
    for (const part of ['careof','village','district','upazila','post','postcode']) {
      const src=$('present_'+part),dest=$('permanent_'+part);
      if(src&&dest) dest.value=src.value;
    }
  });
  $('currently_working').addEventListener('click',()=> {
    $('job_end_date').disabled=$('currently_working').checked;
  });
}'''

def page_setup(browser):
    page=browser.new_page()
    page.set_content(FIXTURE)
    page.evaluate(SIMULATION)
    page.evaluate("window.chrome = {runtime:{onMessage:{addListener(fn){window.__handler=fn}}}}")
    page.add_script_tag(path=str(ROOT/'schema.js'))
    page.add_script_tag(path=str(ROOT/'teletalk-exact.js'))
    page.add_script_tag(content=ORIGIN)
    assert page.evaluate('BDG_TELETALK_EXACT.supports()')
    return page

def invoke(page,action,profile=None,overwrite=False):
    return page.evaluate('''arg => new Promise(resolve =>
        window.__handler({action:arg.action,profile:arg.profile||{},overwrite:arg.overwrite},null,resolve)
    )''', {'action':action,'profile':profile,'overwrite':overwrite})

profile = {
 'basic':{'fullName':'Example Applicant','fullNameBn':'পরীক্ষামূলক নাম',
          'nidStatus':'Yes','nidNo':'1234567890','mobile':'01700000000',
          'religion':'Islam','quota':'Not Applicable'},
 'present':{'district':'Dhaka','upazila':'Khilgaon','postOffice':'Example Post',
            'postCode':'1219'},
 'ssc':{'exam':'S.S.C','group':'Science','board':'Dhaka','result':'GPA(out of 5)',
        'gpa':'4.50','year':'2016'},
 'hsc':{'exam':'H.S.C','group':'Science','board':'Rajshahi','result':'GPA(out of 5)',
        'gpa':'4.90','year':'2018'},
 'graduation':{'exam':'B.Sc Engineering','university':'Daffodil International University',
               'degree':'Computer Science & Engineering','result':'CGPA(out of 4)',
               'cgpa':'3.75','year':'2022','duration':'04 Years'},
 'masters':{'exam':'M.Sc','university':'Daffodil International University',
            'degree':'Computer Science & Engineering','result':'CGPA(out of 4)',
            'cgpa':'3.80','year':'2024','duration':'02 Years'},
 'experience':{'employed':'Private Organization','designation':'Test Engineer',
               'start':'2024-01-01','currentlyWorking':True,'organization':'Example Org',
               'address':'Test Office','description':'Only a test'},
 'qualifications':{'typingSpeed':'Yes','computerSkills':'Yes'}
}
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=page_setup(browser)
    result=invoke(page,'BDG_FILL',profile)
    assert result['ok'],result
    # Exact IDs work even with unlabeled extra GPA fields and two mobile boxes.
    for css,wanted in {'#name':'Example Applicant','#confirm_mobile':'01700000000',
        '#ssc_group':'1','#hsc_group':'1','#gra_subject':'394','#ssc_result':'4.50',
        '#gra_result':'3.75','#present_upazila':'323','#gra_institute':'162',
        '#mas_institute':'162','#job_start_date':'2024-01-01',
        '[name="other_exp[0][value]"]':'Yes'}.items():
        got=page.locator(css).input_value()
        assert got == wanted,(css,got,wanted,result)
    assert page.locator('#if_applicable_mas').is_checked()
    assert page.locator('#if_applicable_exp').is_checked()
    assert page.locator('#currently_working').is_checked()
    assert page.locator('#job_end_date').is_disabled()
    assert not page.locator('#agree').is_checked()
    assert not page.locator('#captcha').input_value()
    assert not result['missing'],result
    print(f"PASS: actual TAX1 IDs, dynamic academic subjects, GPA, masters, experience and qualifications: {len(result['filled'])} filled, {result['unchanged']} preselected.")

    captured=invoke(page,'BDG_CAPTURE_DROPDOWNS')['captured']
    captured_map={(c['section'],c['key']):c['value'] for c in captured}
    assert captured_map[('ssc','exam')]=='S.S.C'
    assert captured_map[('graduation','degree')]=='Computer Science & Engineering'
    assert captured_map[('ssc','gpa')]=='4.50',captured_map
    assert captured_map[('hsc','gpa')]=='4.90',captured_map
    assert captured_map[('graduation','cgpa')]=='3.75',captured_map
    assert captured_map[('masters','cgpa')]=='3.80',captured_map
    assert not any(c['section']=='qualifications' for c in captured)
    print('PASS: captured selected dropdown labels plus all four visible GPA/CGPA numbers, but not eligibility answers.')

    page2=page_setup(browser)
    restrict=invoke(page2,'BDG_FILL',{'permanent':{'district':'Bogura'},
        'basic':{'quota':'Child of Freedom Fighter'}})
    assert page2.locator('#permanent_district').input_value()==''
    assert any('permanent: District' in m and 'choice not available' in m for m in restrict['missing'])
    assert page2.locator('#quota').input_value()=='1'
    print('PASS: honors post-specific district restriction; triggers dependent choice for quota.')

    page3=page_setup(browser)
    page3.select_option('#ssc_exam',label='Dakhil')
    existing=invoke(page3,'BDG_FILL',{'ssc':{'exam':'S.S.C','group':'Science'}},overwrite=False)
    assert page3.locator('#ssc_exam').input_value()=='2'
    assert any('different existing selection preserved' in m for m in existing['missing'])
    assert any('parent selection needs manual review' in m for m in existing['missing'])
    print('PASS: does not overwrite an existing exam or fill its dependent subject incorrectly.')

    page4=page_setup(browser)
    same=invoke(page4,'BDG_FILL',{'present':{'district':'Dhaka','upazila':'Khilgaon'},
        'permanent':{'sameAsPresent':True}})
    assert page4.locator('#same_as_present').is_checked(),same
    assert page4.locator('#permanent_district').input_value()=='40',same
    print('PASS: same-address checkbox uses the website’s own copy mechanism when compatible.')

    page5=page_setup(browser)
    same_block=invoke(page5,'BDG_FILL',{'present':{'district':'Bogura'},
          'permanent':{'sameAsPresent':True}})
    assert not page5.locator('#same_as_present').is_checked()
    assert any('restricted' in m for m in same_block['missing']),same_block
    print('PASS: does not apply same-address when permanent district choice disallows present district.')
    page6=page_setup(browser)
    # Teletalk may preselect a district without populating its child menu.
    page6.evaluate("document.querySelector('#present_district').value='40'")
    predone=invoke(page6,'BDG_FILL',{'present':{'district':'Dhaka','upazila':'Khilgaon'}})
    assert page6.locator('#present_upazila').input_value()=='323',predone
    print('PASS: preselected district with an empty dependent upazila is initialized safely.')

    # Regression: user selects graduation result and manually types 3.09.
    # Learn MUST capture that number, then Fill MUST restore it on a new form.
    page7=page_setup(browser)
    page7.select_option('#gra_result_type',label='CGPA(out of 4)')
    page7.fill('#gra_result','3.09')
    learned=invoke(page7,'BDG_CAPTURE_DROPDOWNS')['captured']
    learnt={(c['section'],c['key']):c['value'] for c in learned}
    assert learnt[('graduation','result')]=='CGPA(out of 4)',learnt
    assert learnt[('graduation','cgpa')]=='3.09',learnt
    page8=page_setup(browser)
    filled=invoke(page8,'BDG_FILL',{'graduation':{'result':learnt[('graduation','result')],
        'cgpa':learnt[('graduation','cgpa')]}})
    assert page8.locator('#gra_result').input_value()=='3.09',filled
    assert not filled['missing'],filled
    print('PASS: the exact reported bug is fixed: learned 3.09 CGPA autofills into its separate input.')

    # Invalid/hidden numeric results must not be imported into a profile.
    page9=page_setup(browser)
    page9.evaluate("document.querySelector('#gra_result').value='3.09'")
    safe=invoke(page9,'BDG_CAPTURE_DROPDOWNS')['captured']
    assert not any(v['section']=='graduation' and v['key']=='cgpa' for v in safe)
    page9.select_option('#gra_result_type',label='CGPA(out of 4)')
    page9.fill('#gra_result','2.75')
    page9.select_option('#gra_result_type',label='1st Class')
    safe=invoke(page9,'BDG_CAPTURE_DROPDOWNS')['captured']
    assert not any(v['section']=='graduation' and v['key']=='cgpa' for v in safe)
    assert not any(v['key'] in ('nidNo','mobile','email') for v in safe)
    print('PASS: never learns hidden or non-GPA numeric results or identity/contact details.')
    browser.close()
